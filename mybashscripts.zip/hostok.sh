#!/bin/bash
#usage pass a host name and target for traceroute 
#ex. testok frankfurt munich 
#tests if host is ok on network: ifconfig, ping, traceroute, unname



echo START

echo `echo "Start" > testok.out`

echo `echo "ifconfig test" >> testok.out`
echo `/sbin/ifconfig -a | tee -a testok.out`


if [ -z "$1" ]	
then
	echo no hostname string provided, default to localhost 
	HOSTSTR='localhost'
	echo for value $HOSTSTR
else
	HOSTSTR=$1
	echo for value $HOSTSTR
fi

echo `echo "ping test" >> testok.out`

echo `ping $HOSTSTR -c 1 | tee -a  testok.out`

if [ -z "$2" ]
then
        echo no target hostname string provided, default to roswell 
        TGTHOSTSTR='roswell'
        echo for value $TGTHOSTSTR
else
        TGTHOSTSTR=$1
        echo for value $TGTHOSTSTR
fi

echo `echo "traceroute test" | tee -a testok.out`

echo `traceroute $TGTHOSTSTR >> testok.out`


echo `echo "uname test" >> testok.out`

echo `uname -a | tee -a testok.out` 


echo `echo "/etc/hosts test" >> testok.out`

echo `cat /etc/hosts  | tee -a testok.out`


echo `echo "/etc/sysconfig test" >> testok.out`

echo `cat /etc/sysconfig/network | tee -a testok.out`







echo `echo "END" >> testok.out`







echo End
