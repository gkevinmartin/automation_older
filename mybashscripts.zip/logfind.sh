#!/bin/bash
#usage pass a log file name and what string to find
#ex. logfind jaws.log DEBUG


LOGDIR="/home/software/jaws330/jboss/server/default/log"
echo $LOGDIR
NEWDIR=""

JAWSLOG="jaws.log"
SERVERLOG="server.log"
HIBLOG="hibernate.log"
EEMLOG="eem.log"

if [ "${1##*.}" = "log" ]
then
	echo Analyzing log file
	
	if [ "${1}" = $JAWSLOG ]
	then
		echo $JAWSLOG 
	elif  [ "${1}" = $SERVERLOG ]
	then
		echo $SERVERLOG 
	elif  [ "${1}" = $HIBLOG ]
	then
		echo $HIBLOG 
	elif  [ "${1}" = $EEMLOG ]
	then
		echo $EEMLOG 
	else
		echo unknown log type
	fi
else
	echo Not a log filename
fi

if [ -z "$2" ]	
then
	echo no search string provided, default to error
	FINDSTR='ERROR'
	echo for value $FINDSTR
else
	FINDSTR=$2
	echo for value $FINDSTR
fi

echo `ping 127.0.0.1`
echo `uname -a`

echo $TRYTHIS

echo End
